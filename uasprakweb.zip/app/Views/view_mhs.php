<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Welcome to CodeIgniter 4!</title>
	<meta name="description" content="The small framework with powerful features">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<body>

	<div class="container">
		<a href="/mahasiswa/create" class="btn btn-primary my-3">Tambah Data</a>
		<div class="col-md-8">
			<table class="table">
				<tr>
					<td>No</td>
					<td>NIM</td>
					<td>Nama</td>
					<td>Kelas</td>
					<td>Email</td>
					<td>Alamat</td>
					<td>Aksi</td>
				</tr>
				<?php $i = 1;
				foreach ($mahasiswa as $m) : ?>
					<tr>
						<td><?= $i++; ?></td>
						<td><?= $m['nim']; ?></td>
						<td><?= $m['nama']; ?></td>
						<td><?= $m['kelas']; ?></td>
						<td><?= $m['email']; ?></td>
						<td><?= $m['alamat']; ?></td>
						<td>
							<a href="/mahasiswa/update/<?= $m['id']; ?>" class="btn btn-success">Update</a>
							<a href="/mahasiswa/delete/<?= $m['id']; ?>" class="btn btn-danger">Delete</a>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		</div>
	</div>

</body>

</html>