<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Welcome to CodeIgniter 4!</title>
	<meta name="description" content="The small framework with powerful features">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<body>

	<div class="container">
		<h2>Update Data Mahasiswa</h2>
		<div class="col-md-8">
			<form action="/mahasiswa/save/<?= $mahasiswa['id']; ?>" method="post">
				<div class="form-group">
					<label>NIM</label>
					<input type="text" class="form-control" name="nim" value="<?= $mahasiswa['nim'] ?>">
				</div>
				<div class="form-group">
					<label>Nama</label>
					<input type="text" class="form-control" name="nama" value="<?= $mahasiswa['nama'] ?>">
				</div>
				<div class="form-group">
					<label>Kelas</label>
					<input type="text" class="form-control" name="kelas" value="<?= $mahasiswa['kelas'] ?>">
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="email" class="form-control" name="email" value="<?= $mahasiswa['email'] ?>">
				</div>
				<div class="form-group">
					<label>Alamat</label>
					<input type="text" class="form-control" name="alamat" value="<?= $mahasiswa['alamat'] ?>">
				</div>
				<button type="submit" class="btn btn-primary">Submit</button>
			</form>
		</div>
	</div>

</body>

</html>